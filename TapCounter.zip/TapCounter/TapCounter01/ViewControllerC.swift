import UIKit

class ViewControllerC: UIViewController
{
    @IBOutlet weak var numberLabel: UILabel!
    //追蹤計數的變數
    var count = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func moreButtom(_ sender: UIButton)
    {
        //點擊按鈕時將計數增加1
        count = count + 1
        //更新UILabel的文字為計數值
        numberLabel.text = String(count)
    }
    
    @IBAction func lessButton(_ sender: UIButton)
    {
        //方法一
//        if numberLabel.text! <= "0" {
//            numberLabel.text = "0"
//        }
//        else {
//            count -= 1
//            numberLabel.text = String(count)
//        }
        //方法二
        if count > 0 {
            count -= 1
            numberLabel.text = String(count)
        }
        //方法三：使用三元條件運算子
//        count = (count > 0) ? count - 1 : 0
//            numberLabel.text = String(count)
    }
    
    
    @IBAction func resetButton(_ sender: UIButton)
    {
        count = 0
        numberLabel.text = "0"
    }

}
