import UIKit

class ViewControllerA: UIViewController
{
    @IBOutlet weak var numberLabel: UILabel!
    //追蹤計數的變數
    var count = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func tapButton(_ sender: UIButton)
    {   //點擊按鈕時將計數增加1
        count = count + 1
        //更新UILabel的文字為計數值
        numberLabel.text = String(count)
    }
    //Reset的按鈕是Bar Button Item、歸零的按鈕是一般Button
    @IBAction func resetButton(_ sender: UIBarButtonItem)
    {
        count = 0
        numberLabel.text = "0"
    }
}

