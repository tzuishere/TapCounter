import UIKit

class ViewControllerB: UIViewController
{
    @IBOutlet weak var numberLabel: UILabel!
    //追蹤計數的變數
    var count = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func moreButtom(_ sender: UIButton)
    {
        //點擊按鈕時將計數增加1
        count = count + 1
        //更新UILabel的文字為計數值
        numberLabel.text = String(count)
    }
    
    @IBAction func lessButton(_ sender: UIButton)
    {
        count = count - 1
        numberLabel.text = String(count)
    }
    
    
    @IBAction func resetButton(_ sender: UIButton)
    {
    count = 0
        numberLabel.text = "0"
    }
}
