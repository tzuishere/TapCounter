import UIKit

class ViewControllerD: UIViewController
{
    @IBOutlet weak var numberLabel: UILabel!
    //追蹤計數的變數
    var count = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    //可以在srotyboard設定最小值、最大值、每次加減多少？
    @IBAction func stepper(_ sender: UIStepper)
    {   //UIStepper的值是浮點數，轉換成整數
        count = Int(sender.value)
        numberLabel.text = String(count)
    }

    @IBAction func resetButton(_ sender: UIButton)
    {
        count = 0
        numberLabel.text = "0"
    }
}
/*
UIStepper官方文件
 https://developer.apple.com/documentation/uikit/uistepper
*/
